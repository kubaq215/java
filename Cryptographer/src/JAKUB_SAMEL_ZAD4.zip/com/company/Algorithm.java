package com.company;

public interface Algorithm
{
    String crypt(String word);
    String decrypt(String word);
}
