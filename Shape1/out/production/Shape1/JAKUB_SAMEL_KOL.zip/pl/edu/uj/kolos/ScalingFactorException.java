package pl.edu.uj.kolos;

public class ScalingFactorException extends Exception
{
    public ScalingFactorException(String errMess)
    {
        super(errMess);
    }
}
